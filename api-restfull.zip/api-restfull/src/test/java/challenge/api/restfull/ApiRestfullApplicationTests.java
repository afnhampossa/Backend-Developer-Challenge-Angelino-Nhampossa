package challenge.api.restfull;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiRestfullApplicationTests {

	@Test
	void contextLoads() {
	}

}
